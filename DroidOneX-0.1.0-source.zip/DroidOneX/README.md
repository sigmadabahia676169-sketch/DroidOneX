# DroidOneX

Emulador de PlayStation 1 para Android, derivado do DuckStation **81da9be2d1040665ebfaf2db6d7fdb710a48a383**, de 7 de junho de 2021, sob **GPLv3**. Esta é uma versão inicial de desenvolvimento, não uma edição oficial do DuckStation. Não há garantia de compatibilidade com 100% da biblioteca.

## Recursos

- Núcleo real do DuckStation, recompilação ARM/ARM64/x86-64, OpenGL/Vulkan/software.
- Configurações globais e por jogo, resolução interna, filtros, PGXP, áudio, velocidade, controles de toque e físicos, memory cards e save states, herdados da revisão indicada.
- Perfis DroidOneX: desempenho, precisão e gráficos. Eles alteram um conjunto de opções globais; opções por jogo continuam prevalecendo.
- Biblioteca com busca recursiva. Abra o **CUE** para jogos com várias faixas; BIN sozinho não descreve áudio nem o layout completo do disco.
- Leitura CHD, BIN/CUE e ISO. ISO9660 de 2048 bytes/setor recebe reconstrução Mode 1; ISO bruto de 2352 bytes/setor também é aceito. Imagens já sem áudio/dados do disco original não podem recuperá-los por conversão.
- Importação ZIP/7z pelo menu **DroidOneX: perfis e arquivos**. Extração antes de jogar, preservando nomes e subpastas. Limites: 8 GiB extraídos, 10.000 entradas e 64 MiB de memória para o decodificador 7z. Sem suporte a senha, volumes divididos ou extração recursiva de arquivos compactados dentro de outros arquivos compactados.
- Conversor **para BIN+CUE sem compressão**, preservando faixas, índices e flags. CHD/BIN/ISO podem ser escolhidos pelo seletor; CUE deve ser convertido pelo menu do jogo após adicionar a pasta à biblioteca. Subcanais especiais detectados e imagens multidisco são recusados. O seletor copia apenas o arquivo escolhido: para discos acompanhados de SBI, adicione a pasta completa e use o menu do jogo; o conversor não consegue detectar um SBI que não foi disponibilizado. Não gera CHD, nem restaura informações perdidas no arquivo original.
- Nome, ícone e cores DroidOneX a partir da imagem fornecida.

## Instalar e usar

Android 8.0 (API 26) ou superior. Use o APK da arquitetura do aparelho (normalmente ARM64). Os APKs de desenvolvimento são assinados com chave de debug e não são uma publicação na Play Store. A configuração antiga de target SDK 29 foi mantida; aparelhos recentes podem exibir avisos de versão antiga. Dispositivos que exigem bibliotecas nativas compatíveis com páginas de 16 KiB ainda não foram validados.

1. Instale o APK e conceda as permissões solicitadas.
2. Menu → **Importar BIOS**: escolha uma BIOS extraída do seu console. **Nenhuma BIOS Sony ou jogo acompanha o aplicativo.**
3. Adicione uma pasta de jogos, incluindo subpastas, ou importe ZIP/7z nas ferramentas.
4. Após importar/converter, volte à biblioteca e use **Buscar novos jogos**.
5. Comece com resolução nativa. Ajuste melhorias por jogo conforme a capacidade do aparelho.

Dados, BIOS, saves e arquivos importados ficam em `Android/data/com.droidonex.emulator/files` (ou armazenamento interno privado como alternativa). **Desinstalar remove esses dados**; mantenha os originais e faça backup. Importações e conversões exigem espaço para uma cópia temporária e a saída. Mantenha a tela de ferramentas aberta até concluir; interrupção do processo pode deixar arquivos incompletos, que devem ser removidos antes de repetir.

## Compilar

Ferramentas fixadas em `android/`: JDK 11, Gradle 7.5.1, Android Gradle Plugin 7.4.2 com D8/R8 8.3.37, SDK 29, Build Tools 30.0.3, NDK 21.4.7075529 e CMake 3.10.2.4988404.

```bash
export ANDROID_HOME=/caminho/para/android-sdk
cd android
./gradlew :app:assembleDebug :app:testDebugUnitTest
```

APKs em `android/app/build/outputs/apk/debug/`, separados para `arm64-v8a`, `armeabi-v7a` e `x86_64`. O wrapper baixa dependências Google Maven/Maven Central. Em redes com CA corporativa, configure um trust store Java autorizado; não desative TLS.

Testes nativos de leitura ISO e conversão, além dos testes comuns herdados:

```bash
mkdir build-host && cd build-host
cmake .. -DBUILD_QT_FRONTEND=OFF -DBUILD_NOGUI_FRONTEND=OFF -DUSE_SDL2=OFF \
  -DUSE_X11=OFF -DUSE_WAYLAND=OFF -DUSE_EGL=OFF -DUSE_EVDEV=OFF \
  -DENABLE_CHEEVOS=OFF -DENABLE_DISCORD_PRESENCE=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build . --target common-tests -- -j2
./bin/common-tests
```

## Origem e licenças

Consulte [LICENSE](LICENSE), [CONTRIBUTORS.md](CONTRIBUTORS.md) e as licenças em `dep/`. Fontes históricas: https://github.com/stenzek/duckstation/tree/81da9be2d1040665ebfaf2db6d7fdb710a48a383. A licença da versão **atual** do DuckStation não foi usada para este derivado.

Alterações DroidOneX, outubro de 2026: identidade Android, application ID separado, armazenamento privado, perfis, importador ZIP/7z, exportador BIN+CUE, suporte ISO9660 Mode 1 e testes. O namespace Java/JNI original foi mantido por compatibilidade técnica, sem indicar afiliação.

Dependências adicionais: Apache Commons Compress 1.27.1 (Apache-2.0, https://commons.apache.org/proper/commons-compress/) e XZ for Java 1.10 (0BSD, https://tukaani.org/xz/java.html). Ao distribuir o APK, disponibilize também o código-fonte correspondente, scripts de construção e licenças conforme GPLv3. Não remova os créditos upstream.

## Limitações de validação

Compilar e testar arquivos sintéticos não comprova execução de jogos. A base de 2021 não contém correções posteriores do DuckStation. BIOS, inicialização de jogos, GPU, áudio, controles e desempenho em dispositivos físicos precisam de validação. Serviços online herdados podem ter mudado desde 2021. Não há alegação de maturidade ou compatibilidade total.
