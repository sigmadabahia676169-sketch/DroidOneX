package com.github.stenzek.duckstation;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DroidOneXToolsActivity extends AppCompatActivity {
    private static final int IMPORT = 41, CONVERT = 42;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView status;
    private boolean busy;
    private static native String convertDisc(String source, String destination);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (!AndroidHostInterface.hasInstance() && !AndroidHostInterface.createInstance(this)) {
            finish(); return;
        }
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int padding = (int)(20 * getResources().getDisplayMetrics().density);
        layout.setPadding(padding, padding, padding, padding);
        ScrollView scroll = new ScrollView(this); scroll.addView(layout); setContentView(scroll);
        TextView intro = new TextView(this);
        intro.setText("DroidOneX\n\nPerfis globais: configurações por jogo continuam tendo prioridade. Você pode ajustar cada opção nas Configurações. Melhorias gráficas podem causar incompatibilidades.");
        layout.addView(intro);
        button(layout, "Desempenho • OpenGL, 1×", () -> profile(0));
        button(layout, "Precisão • software, resolução nativa", () -> profile(1));
        button(layout, "Gráficos • OpenGL, 3× e PGXP", () -> profile(2));
        button(layout, "Importar ZIP / 7z", () -> pick(IMPORT));
        button(layout, "Converter CHD / BIN / ISO para BIN+CUE", () -> new AlertDialog.Builder(this)
                .setTitle("Converter disco")
                .setMessage("Saída sem compressão: ocupa mais espaço. Para BIN+CUE com várias faixas, use a opção da biblioteca no menu do jogo. Aqui selecione CHD, BIN de faixa única ou ISO. Subcanais especiais detectados são recusados. Se houver arquivo SBI junto ao disco, converta pelo menu do jogo na biblioteca; este seletor importa apenas o arquivo escolhido. O original será preservado.")
                .setPositiveButton("Selecionar", (d,w) -> pick(CONVERT)).setNegativeButton("Cancelar", null).show());
        status = new TextView(this);
        status.setText("Importação preserva subpastas e nomes de BIN+CUE. ZIP/7z são extraídos antes de jogar (até 8 GiB, 10.000 entradas; 7z sem senha).\n\nBIOS: importe uma cópia do seu console pelo menu principal.\n\nArquivos ficam na pasta privada do aplicativo e são removidos ao desinstalar. Faça backup dos saves e dos discos antes de desinstalar.\n\nBase: DuckStation GPLv3, revisão de junho de 2021. Compatibilidade total não foi comprovada.");
        layout.addView(status);
        String source = getIntent().getStringExtra("convertPath");
        if (state == null && source != null) new AlertDialog.Builder(this).setTitle("Converter para BIN+CUE")
                .setMessage("O original será preservado. A saída ocupa espaço sem compressão; subcanais especiais não são convertidos.")
                .setPositiveButton("Converter", (d,w) -> runJob(() -> convert(source)))
                .setNegativeButton("Cancelar", null).show();
    }
    private void button(LinearLayout parent, String label, Runnable action) {
        Button button = new Button(this); button.setText(label);
        button.setOnClickListener(v -> { if (!busy) action.run(); }); parent.addView(button);
    }
    private void profile(int mode) {
        new AlertDialog.Builder(this).setTitle("Aplicar perfil?")
                .setMessage("Substitui as opções globais de CPU, GPU e velocidade usadas por este perfil. Ajustes por jogo continuam ativos.")
                .setNegativeButton("Cancelar", null).setPositiveButton("Aplicar", (d,w) -> {
                    SharedPreferences.Editor e = PreferenceManager.getDefaultSharedPreferences(this).edit();
                    e.putString("GPU/Renderer", mode == 1 ? "Software" : "OpenGL")
                     .putString("GPU/ResolutionScale", mode == 2 ? "3" : "1")
                     .putString("GPU/MSAA", "1").putString("GPU/TextureFilter", "Nearest")
                     .putString("CPU/ExecutionMode", mode == 1 ? "CachedInterpreter" : "Recompiler")
                     .putString("CPU/Overclock", "100")
                     .putString("Main/EmulationSpeed", "1.0")
                     .putBoolean("GPU/PGXPEnable", mode == 2)
                     .putBoolean("GPU/PGXPTextureCorrection", true).putBoolean("GPU/PGXPCulling", true)
                     .putBoolean("GPU/PGXPDepthBuffer", false).putBoolean("GPU/PGXPCPU", false)
                     .putBoolean("GPU/TrueColor", mode == 2).putBoolean("GPU/ScaledDithering", mode == 2)
                     .putBoolean("GPU/DisableInterlacing", mode != 1)
                     .putBoolean("GPU/WidescreenHack", false).putBoolean("GPU/ForceNTSCTimings", false)
                     .putBoolean("BIOS/PatchFastBoot", mode != 1)
                     .putString("CDROM/ReadSpeedup", "1").putString("CDROM/SeekSpeedup", "1").apply();
                    status.setText("Perfil aplicado. Abra Configurações para personalizar. Reinicie o jogo para aplicar.");
                }).show();
    }
    private void pick(int request) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, request);
    }
    interface Job { String run() throws Exception; }
    private void runJob(Job job) {
        busy = true; status.setText("Processando… mantenha esta tela aberta.");
        worker.execute(() -> {
            String result;
            try { result = job.run(); } catch (Exception e) { result = "Falha: " + e.getMessage(); }
            final String message = result;
            runOnUiThread(() -> { busy = false; if (!isDestroyed()) status.setText(message); });
        });
    }
    private File library() throws IOException {
        File f = new File(AndroidHostInterface.getUserDirectory(), "games");
        if (!f.isDirectory() && !f.mkdirs()) throw new IOException("Não foi possível criar a biblioteca.");
        return f;
    }
    private String convert(String source) throws IOException {
        File folder = new File(library(), "converted-" + java.util.UUID.randomUUID());
        if (!folder.mkdir()) throw new IOException("Não foi possível criar o destino.");
        String error = convertDisc(source, folder.getAbsolutePath());
        if (error != null) { ArchiveImporter.deleteTree(folder); throw new IOException(error); }
        GameDirectoriesActivity.addSearchDirectory(this, library().getAbsolutePath(), true);
        return "Conversão concluída: " + folder + "\nVolte à biblioteca e use Buscar novos jogos.";
    }
    @Override public void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null || busy) return;
        if (request != IMPORT && request != CONVERT) return;
        Uri uri = data.getData();
        runJob(() -> {
            File source = File.createTempFile("disc-", request == IMPORT ? ".archive" : extension(uri), getCacheDir());
            try {
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(source)) {
                    if (in == null) throw new IOException("Arquivo indisponível.");
                    byte[] buffer = new byte[65536]; int n; long total = 0;
                    while ((n = in.read(buffer)) != -1) {
                        total += n; if (total > ArchiveImporter.MAX_BYTES || Thread.currentThread().isInterrupted()) throw new IOException("Arquivo excede o limite ou operação interrompida.");
                        out.write(buffer, 0, n);
                    }
                }
                if (request == CONVERT) return convert(source.getAbsolutePath());
                File folder = new File(library(), "imported-" + java.util.UUID.randomUUID());
                if (!folder.mkdir()) throw new IOException("Destino indisponível.");
                try { new ArchiveImporter(folder).extract(source); }
                catch (Exception e) { ArchiveImporter.deleteTree(folder); throw e; }
                GameDirectoriesActivity.addSearchDirectory(this, library().getAbsolutePath(), true);
                return "Importado: " + folder + "\nVolte à biblioteca e use Buscar novos jogos. Para BIN+CUE, abra o CUE.";
            } finally { source.delete(); }
        });
    }
    private String extension(Uri uri) throws IOException {
        String name = null;
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        }
        if (name != null) {
            String lower = name.toLowerCase(java.util.Locale.ROOT);
            for (String ext : new String[]{".chd", ".bin", ".iso"}) if (lower.endsWith(ext)) return ext;
        }
        throw new IOException("Selecione CHD, BIN ou ISO. Para CUE, converta pelo menu do jogo na biblioteca.");
    }
    @Override public void onBackPressed() {
        if (busy) Toast.makeText(this, "Aguarde a operação terminar.", Toast.LENGTH_SHORT).show();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
