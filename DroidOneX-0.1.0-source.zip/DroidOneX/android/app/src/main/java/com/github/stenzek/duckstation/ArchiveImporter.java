package com.github.stenzek.duckstation;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.sevenz.SevenZFileOptions;
import java.io.*;
import java.util.zip.*;

/** Imports into a new, private staging directory. Caller deletes it on failure. */
final class ArchiveImporter {
    static final long MAX_BYTES = 8L * 1024 * 1024 * 1024;
    static final int MAX_ENTRIES = 10000;
    private long total;
    private int entries;
    private final File root;
    ArchiveImporter(File root) { this.root = root; }

    private File target(String name) throws IOException {
        if (++entries > MAX_ENTRIES) throw new IOException("Arquivo contém entradas demais.");
        if (name == null || name.isEmpty() || name.contains("\\") || name.startsWith("/"))
            throw new IOException("Caminho inválido no arquivo.");
        File file = new File(root, name).getCanonicalFile();
        if (!file.getPath().startsWith(root.getCanonicalPath() + File.separator))
            throw new IOException("Caminho fora da pasta de destino.");
        return file;
    }
    private void mkdir(File directory) throws IOException {
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Não foi possível criar a pasta.");
    }
    private void write(InputStream input, File output) throws IOException {
        mkdir(output.getParentFile());
        if (!output.createNewFile()) throw new IOException("Entrada duplicada: " + output.getName());
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
            byte[] buffer = new byte[65536];
            int n;
            while ((n = input.read(buffer)) != -1) {
                total += n;
                if (total > MAX_BYTES || Thread.currentThread().isInterrupted())
                    throw new IOException("Limite de extração excedido ou operação interrompida.");
                out.write(buffer, 0, n);
            }
        }
    }
    void extract(File archive) throws IOException {
        int magic;
        try (InputStream input = new FileInputStream(archive)) { magic = input.read(); }
        if (magic == 0x37) {
            try (SevenZFile seven = new SevenZFile(archive,
                    SevenZFileOptions.builder().withMaxMemoryLimitInKb(65536).build())) {
                SevenZArchiveEntry e;
                while ((e = seven.getNextEntry()) != null) {
                    File destination = target(e.getName());
                    if (e.isDirectory()) { mkdir(destination); continue; }
                    write(new InputStream() {
                        @Override public int read() throws IOException { return seven.read(); }
                        @Override public int read(byte[] b, int o, int n) throws IOException { return seven.read(b, o, n); }
                    }, destination);
                }
            }
        } else {
            try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(archive)))) {
                ZipEntry e;
                while ((e = zip.getNextEntry()) != null) {
                    File destination = target(e.getName());
                    if (e.isDirectory()) mkdir(destination); else write(zip, destination);
                    zip.closeEntry();
                }
            }
        }
        if (entries == 0) throw new IOException("ZIP/7z vazio ou não reconhecido.");
    }
    static void deleteTree(File file) {
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }
}
