#include "android_host_interface.h"
#include "common/cd_image.h"
#include "common/error.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_github_stenzek_duckstation_DroidOneXToolsActivity_convertDisc(
    JNIEnv* env, jclass, jstring source, jstring destination)
{
  const auto input = AndroidHelpers::JStringToString(env, source);
  const auto output = AndroidHelpers::JStringToString(env, destination);
  auto image = CDImage::Open(input.c_str(), nullptr);
  if (!image) return env->NewStringUTF("Disco nao reconhecido.");
  Common::Error error;
  if (!image->ExportBinCue(output.c_str(), &error)) return env->NewStringUTF(error.GetMessage().GetCharArray());
  return nullptr;
}
