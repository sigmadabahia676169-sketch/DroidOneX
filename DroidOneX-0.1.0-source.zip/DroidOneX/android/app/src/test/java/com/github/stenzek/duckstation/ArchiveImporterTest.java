package com.github.stenzek.duckstation;

import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.zip.*;
import org.apache.commons.compress.archivers.sevenz.*;
import static org.junit.Assert.*;

public class ArchiveImporterTest {
    @Rule public TemporaryFolder temp = new TemporaryFolder();
    private File zip(String name, byte[] data) throws IOException {
        File file = temp.newFile();
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(file))) {
            out.putNextEntry(new ZipEntry(name)); out.write(data); out.closeEntry();
        }
        return file;
    }
    @Test public void preservesNestedFiles() throws Exception {
        File root = temp.newFolder();
        new ArchiveImporter(root).extract(zip("game/disc.bin", new byte[]{1,2,3}));
        assertArrayEquals(new byte[]{1,2,3}, Files.readAllBytes(new File(root,"game/disc.bin").toPath()));
    }
    @Test public void rejectsTraversal() throws Exception {
        File root = temp.newFolder();
        try { new ArchiveImporter(root).extract(zip("../escape.bin", new byte[]{1})); fail(); }
        catch (IOException expected) { assertFalse(new File(root.getParentFile(),"escape.bin").exists()); }
    }
    @Test public void rejectsAbsolutePaths() throws Exception {
        try { new ArchiveImporter(temp.newFolder()).extract(zip("/escape.bin", new byte[]{1})); fail(); }
        catch (IOException expected) { assertTrue(expected.getMessage().contains("inválido")); }
    }
    @Test public void refusesToOverwrite() throws Exception {
        File root = temp.newFolder(); File existing = new File(root,"disc.bin");
        Files.write(existing.toPath(), new byte[]{7});
        try { new ArchiveImporter(root).extract(zip("disc.bin", new byte[]{1})); fail(); }
        catch (IOException expected) { assertArrayEquals(new byte[]{7}, Files.readAllBytes(existing.toPath())); }
    }
    @Test public void readsSevenZip() throws Exception {
        File source = temp.newFile(); Files.write(source.toPath(), new byte[]{4,5});
        File archive = temp.newFile();
        try (SevenZOutputFile out = new SevenZOutputFile(archive)) {
            out.putArchiveEntry(out.createArchiveEntry(source,"nested/disc.cue"));
            out.write(new byte[]{4,5}); out.closeArchiveEntry();
        }
        File root = temp.newFolder(); new ArchiveImporter(root).extract(archive);
        assertArrayEquals(new byte[]{4,5}, Files.readAllBytes(new File(root,"nested/disc.cue").toPath()));
    }
    @Test public void rejectsNonArchives() throws Exception {
        File f = temp.newFile(); Files.write(f.toPath(), new byte[]{1,2,3});
        try { new ArchiveImporter(temp.newFolder()).extract(f); fail(); } catch (IOException expected) { }
    }
}
